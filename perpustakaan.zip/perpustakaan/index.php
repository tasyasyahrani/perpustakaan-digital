<?php
include 'koneksi.php';
session_start();

if (isset($_POST['tombol'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $level = $_POST['level'];

    if ($level == "admin") {
        $query = mysqli_query(
            $koneksi,
            "SELECT * FROM admin
         WHERE username='$username'
         AND password='$password'"
        );

        if (mysqli_num_rows($query) > 0) {
            $data = mysqli_fetch_array($query);
            $_SESSION['id_admin']  = $data['id_admin'];
            $_SESSION['username']  = $data['username'];
            $_SESSION['nama_admin']  = $data['nama_admin'];
            header("location: admin/dashboard.php");
            exit;
        } else {
            echo "<script>alert('Login Admin Gagal');</script>";
        }
    }

    if ($level == "anggota") {
        $query = mysqli_query(
            $koneksi,
            "SELECT * FROM anggota
             WHERE username='$username'
            AND password='$password'"
        );

        if (mysqli_num_rows($query) > 0) {
            $data = mysqli_fetch_array($query);
            $_SESSION['id_anggota']  = $data['id_anggota'];
            $_SESSION['nis']  = $data['nis'];
            $_SESSION['username']  = $data['username'];
            $_SESSION['nama_anggota']  = $data['nama_anggota'];
            $_SESSION['kelas']  = $data['kelas'];
            header("location: anggota/dashboard.php");
            exit;
        } else {
            echo "<script>alert('Login Anggota Gagal');</script>";
        }
    }
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Login</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
</head>

<body class="bg-light">

    <div class="vh-100 row justify-content-center align-content-center">
        <form method="post" class="col-md-3 border p-4 bg-white rounded-4 text-center">

            <img src="logo.jpg" width="120" class="mb-2">
            <h5 class="mb-3">Login Perpustakaan Sekolah Digital</h5>

            <input type="text" name="username" class="form-control mb-3" placeholder="Masukan Username" required>

            <input type="password" name="password" class="form-control mb-3" placeholder="Masukan Password" required>

            <select name="level" class="form-control mb-3" required>
                <option value="">Login Sebagai</option>
                <option value="admin">Admin</option>
                <option value="anggota">"Anggota"</option>
            </select>

            <button name="tombol" type="submit" class="btn btn-success w-100">
                Login
            </button>
            <div class="text-center mt-3">
                Belum punya akun? <a href="pendaftaran-anggota.php">Daftar Anggota</a>
            </div>
        </form>
    </div>
</body>

</html>