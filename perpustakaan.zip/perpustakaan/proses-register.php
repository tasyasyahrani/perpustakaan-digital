<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Daftar Angota</title>
    <link href="https://cdn:jsdelivr.net/npm/bootsrap@5.3.2/dist/css/bootsrap.min.css" rel="stylesheet">
</head>
<body class="bg-dark d-flex justify-content-center align-items-center vh-100">

<div class="card p-4" style="width:420px;">
    <h3 class="text-center mb-3">Daftar Anggota</h3>

    <form action="proses_register.php" method="POST">
        <div class="mb-3">
            <input type="email" name="email" class="form-control" placeholder="Email" required>
        </div>

        <div class="mb-3">
            <input type="password" name="password" class="form-control" placeholder="Password" required>
        </div>

        <div class="mb-3">
            <input type="password" name="password2" class="form-control" placeholder=" Ulangi Password" required>
        </div>

        <!-- role DIKUNCI sebagai ANGGOTA -->
        <input type="hidden" name="role" value="ANGGOTA">

        <button type="submit" class="btn btn-success w-100">Daftar</button>
    </form>

    <div class="text-center mt-3">
        Sudah punya akun? <a href="login.php">Login</a>
    </div>
</div>

</body>
</html>