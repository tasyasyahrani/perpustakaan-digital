<?php
session_start();
if (empty($_SESSION['id_anggota'])) {
    header("Location:../login-anggota.php");
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Halaman Anggota | Aplikasi perpustakaan Sekolah Digital</title>
    <link href="../css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-light">
    <div class="container mt-3 mb-3">
        <h4>Halaman Anggota | Aplikasi perpustakaan Sekolah Digital</h4>
        <a href="dashboard.php" class="btn btn-success text-white">Dashboard</a>
        <a href="?halaman=history" class="btn btn-success text-white">History peminjaman</a>
        <a href="logout.php" class="btn btn-danger text-white">Logout</a>
        <div class="card p-3 mt-3">
            <?php
            include '../koneksi.php';
            $halaman = isset($_GET['halaman']) ? $_GET['halaman'] : "";
            if ($halaman != "" && file_exists($halaman . ".php")) {
                include $halaman . ".php";
            } else { ?>
                <h4>Selamat Datang <?= $_SESSION['nama_anggota']; ?> 👋</h4>
                <form action="?halaman=cari" method="post">
                    <label class="text-muted">Yuk cari buku.</label>
                    <input type="text" name="kunci" class="form-control mb-2" required placeholder="Masukan Judul Buku">
                    <button type="submit" class="btn btn-primary mb-4">🔎 Cari</button>
                </form>
                <h4>🛒 Daftar Buku Yang Dipinjam:</h4>
                <table class="table table-bordered">
                    <tr class="fw-bold">
                        <td>No</td>
                        <td>Judul Buku</td>
                        <td>Tanggal Pinjam</td>
                        <td>Pengembalian</td>
                    </tr>
                    <?php
                    $no = 1;
                    $query = "SELECT*FROM transaksi,buku WHERE buku.id_buku=transaksi.id_buku AND transaksi. 
                    id_anggota='$_SESSION[id_anggota]' AND status_transaksi='peminjaman'";
                    $data = mysqli_query($koneksi, $query);
                    foreach ($data as $peminjaman) { ?>
                        <tr>
                            <td><?= $no++; ?></td>
                            <td><?= $peminjaman['judul_buku']; ?></td>
                            <td><?= $peminjaman['tgl_pinjam']; ?></td>
                            <td>
                                <?php
                                $link = "'Pengembalian Buku {$peminjaman['judul_buku']}', {$peminjaman['id_transaksi']}, {$peminjaman['id_buku']}";
                                ?>
                                <a onclick="pengembalian(<?= $link ?>)" class="btn btn-success">
                                    ✅ pengembalian
                                </a>
                            </td>
                        </tr>
                    <?php } ?>
                </table>
                <hr>
                <h4>📚 Daftar Buku</h4>
                <div class="row">
                    <?php
                    $data_buku = mysqli_query($koneksi, "SELECT*FROM buku ORDER BY id_buku DESC");
                    foreach ($data_buku as $buku) {
                    ?>
                        <div class="col-md-3">
                            <div class="card shadow-sm p-3 mb-3">
                                <h5><?= $buku['judul_buku'] ?></h5>
                                <p><strong>pengarang :</strong> <?= $buku['pengarang'] ?></p>
                                <p><strong>penerbit :</strong> <?= $buku['penerbit'] ?></p>
                                <p><strong>Tahun :</strong> <?= $buku['tahun_terbit'] ?></p>
                                <?php if ($buku['status'] == "tersedia") { ?>
                                    <span class="badge bg-success mb-1">✅ Tersedia</span>
                                    <?php
                                    $link = "'❓ apakah anda yakin ingin meminjam buku $buku[judul_buku]',$buku[id_buku]";
                                    ?>
                                    <a onclick="pinjam(<?= $link  ?>)" class="btn btn-primary text-white w-100">🛒 pinjam</a>
                                <?php } else { ?>
                                    <span class="badge bg-danger mb-1">❌ Tidak Tersedia</span>
                                    <button class="btn btn-secondary w-100 disabled">🛒 Pinjam</button>
                                <?php } ?>
                            </div>
                        </div>
                    <?php } ?>
                </div>
            <?php } ?>
        </div>
    </div>
    <script>
        function pinjam(pesan, id_buku) {
            if (confirm(pesan)) {
                window.location.href = '?halaman=peminjaman&id=' + id_buku;
            }
        }

        function pengembalian(pesan, id_transaksi, id_buku) {
            if (confirm(pesan)) {
                window.location.href = '?halaman=pengembalian&id=' + id_transaksi + '&buku=' + id_buku;
            }
        }
    </script>
</body>

</html>