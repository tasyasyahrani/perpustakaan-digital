<h4> 🛒Data Peminjaman</h4>
<a href="?halaman=input_peminjaman" class="btn btn-secondary">
    ➕ Tambah Data Peminjaman
</a>
<table class="table table-bordered mt-3">
    <tr class="fw-bold">
        <td>No</td>
        <td>NIS</td>
        <td>Nama Anggota</td>
        <td>Judul Buku</td>
        <td>Tanggal Pinjam</td>
        <td>Kelola</td>
    </tr>
    <?php
    include'../koneksi.php';
    $no = 1;
    $query = "SELECT*FROM transaksi,buku,anggota WHERE buku.id_buku=transaksi.id_buku AND anggota.id_anggota=transaksi.id_anggota AND transaksi.status_transaksi='peminjaman' ORDER BY transaksi.id_transaksi DESC";
    $data = mysqli_query($koneksi, $query);
    foreach($data as $peminjam){ ?>
    <tr>
        <td><?=  $no++; ?></td>
        <td><?= $peminjam['nis']; ?></td>
        <td><?= $peminjam['nama_anggota']; ?></td>
        <td><?= $peminjam['judul_buku']; ?></td>
        <td><?= $peminjam['tgl_pinjam']; ?></td>
        <td>
            <?php
            $pesan = "✅ pengembalian buku oleh $peminjam[nama_annggota], Buku $peminjam[judul_buku]";
            $isi = "'$pesan',$peminjam[id_transaksi],$peminjam[id_buku]";
            ?>
            <a onclick="pengembalian(<?= $isi ?>)" class="btn btn-success">✅ pengembalian</a>
            <?php
            $pesan = "🗑️ Anda Yakin ingin menghapus buku oleh $peminjam[nama_anggota], Buku $peminjam[judul_buku]";
            $isi = "'$pesan',$peminjam[id_transaksi],$peminjam[id_buku]";
            ?>
            <a onclick="hapus(<?= $isi ?>)" class="btn btn-danger">🗑️ hapus</a>
        </td>
    </tr>
    <?php } ?>
</table>
<h4>✅Data pengembalian</h4>

<table class="table table-bordered mt-3">
    <tr class="fw-bold">
        <td>No</td>
        <td>NIS</td>
        <td>Nama Anggota</td>
        <td>Judul Buku</td>
        <td>Tanggal Pinjam</td>
        <td>tanggal pengembalian</td>
        <td>kelola</td>
    </tr>
    <?php
    include'../koneksi.php';
    $no = 1;
    $query = "SELECT*FROM transaksi,buku,anggota WHERE buku.id_buku=transaksi.id_buku AND anggota.id_anggota=transaksi.id_anggota AND transaksi.status_transaksi='pengembalian' ORDER BY transaksi.id_transaksi DESC";
    $data = mysqli_query($koneksi, $query);
    foreach($data as $peminjam){ ?>
    <tr>
        <td><?=  $no++; ?></td>
        <td><?= $peminjam['nis']; ?></td>
        <td><?= $peminjam['nama_anggota']; ?></td>
        <td><?= $peminjam['judul_buku']; ?></td>
        <td><?= $peminjam['tgl_pinjam']; ?></td>
        <td><?= $peminjam['tgl_kembali']; ?></td>
        <td>
            <?php
            $pesan = "🗑️ Anda Yakin ingin menghapus buku oleh $peminjam[nama_anggota], Buku $peminjam[judul_buku]";
            $isi = "'$pesan',$peminjam[id_transaksi],$peminjam[id_buku]";
            ?>
            <a onclick="hapus(<?= $isi ?>)" class="btn btn-danger">🗑️ hapus</a>
        </td>
        </tr>
        <?php } ?>
        </table>
        <script>
            function pengembalian(pesan,id_transaksi,id_buku){
                if(confirm(pesan)){
                    window.location.href = '?halaman=proses_pengembalian&id='+id_transaksi+'&buku'+id_buku;
}
            }
            function pengembalian(pesan,id_transaksi,id_buku){
                if(confirm(pesan)){
                    window.location.href = '?halaman=hapus&id='+id_transaksi+'&buku'+id_buku;
}
            }
        </script>